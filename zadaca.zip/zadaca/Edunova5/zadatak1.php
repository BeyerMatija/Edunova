<?php

//ispišite sve parne brojeve od 1 do 100
// unos korisnika
$od=5895;
$do=10000;


for($i=$od;$i<=$do;$i++){
	echo ($i%2==0) ? $i . "<br />" : "";
}

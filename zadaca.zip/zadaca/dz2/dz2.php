<?php 
$d1 = $_GET["d1"];
$d2 = $_GET["d2"];
$d3 = $_GET["d3"];
$d4 = $_GET["d4"];
$rez = $d1 + $d2 + $d3 * $d4;
?>



<?php echo "Rezultat" ?>

<?php echo $rezultat ?>
	

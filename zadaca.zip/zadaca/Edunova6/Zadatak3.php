<?php

//u tabličnom prikazu s dvije kolone ispisati sve 
//ključeve i vrijednost $_SERVER niza
//print_r($_SERVER);
?>
<style>
	td{
		border: 2px solid blue;
	}
	table{
		border-collapse: collapse;
	}
</style>
<table>
	<tr>
		<td>Ključ</td>
		<td>Vrijednost</td>
	</tr>
	
	<?php foreach($_SERVER as $k => $v): ?>
	<tr>
		<td><?php echo $k;  ?></td>
		<td><?php echo $v;  ?></td>
	</tr>
	<?php endforeach; ?>
	
</table>
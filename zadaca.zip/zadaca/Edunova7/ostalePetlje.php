<?php

$t=0;

while($t<10){
	echo ++$t . "<br />";
}

$t=0;
do{
	echo ++$t . "<br />";
}while($t<10);

//beskonačna while
//while(true){
	
//}

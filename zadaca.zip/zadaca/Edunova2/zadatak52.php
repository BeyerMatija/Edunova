<?php include_once 'konfiguracija.php'; ?>
<!doctype html>
<html class="no-js" lang="en" dir="ltr">
	<head>
		<?php include_once 'head.php'; ?>
	</head>
	<body>
		<header>
			<?php include_once 'izbornik.php'; ?>
			<?php include_once 'zaglavlje.php'; ?>
		</header>

		<div class="row">
			<div class="large-4 large-centered columns">
				
				
				Zadatak 5.2.
				<form method="post">
					<label for="broj">Unesite broj za provjeru da li je prim</label>
					<input type="text" name="broj" id="broj" 
					value="<?php echo isset($_POST["broj"]) ? $_POST["broj"] : 10 ?>" />
					<input type="submit" value="Provjeri" class="expanded button" />
				</form>
				
				<?php 
				if(isset($_POST["broj"])){
					set_time_limit(0);
					$prim=true;
					for($i=2;$i<$_POST["broj"];$i++){
						if($_POST["broj"]%$i==0){
							$prim=false;
							break;
						}
					}
					echo $prim ? "JE PRIM" : "NIJE PRIM";
				}
				
				?>
				
			</div>
		</div>

		

		<footer>
			<?php include_once 'podnozje.php'; ?>
		</footer>

		<?php include_once 'skripte.php'; ?>
	</body>
</html>

<div class="row" style="max-width: 100rem; text-align: center;">
	<hr />
	&copy; Matija Beyer 
	
	<?php 
	
	if($_SERVER["HTTP_HOST"]==="localhost"){
		echo ", <span style=\"color: red\">Lokalno</span>";
	}
	
	?>
	
</div>

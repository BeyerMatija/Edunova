<?php


for ($i=100; $i<=1000 ; $i++) {
	
echo "$i <br> <br>";
	
}

?> 
<?php

$v="Edunova";


echo $v;

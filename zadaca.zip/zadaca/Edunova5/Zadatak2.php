<?php

//ispišite tablicu množenja 10x10

$x=10;
$y=10;
?>
<style>
	table{
		border-collapse: collapse;;
	}
	td{
		text-align: right;
		width: 20px;
		border: 1px solid blue;
	}
</style>
<table>
<?php
for($i=1;$i<$x;$i++){
	?>
	<tr>
	<?php
	for($j=1;$j<$y;$j++){
	
		?>
	<td><?php echo $i*$j; ?></td>
	<?php
	}
	?>
	</tr>
	<?php
}
?>
</table>
<?php

//ispisati ukupno elemenata u $_SERVER nizu
//$zbroj=0;
//foreach ($_SERVER as $key => $value) {
//	 $zbroj++;
	//echo $key . $zbroj . "<br />";
//}
//echo $zbroj;
//echo "<hr />";
echo count($_SERVER);
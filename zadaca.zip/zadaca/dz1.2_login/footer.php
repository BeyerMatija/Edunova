<div id="divFooter" class="footerArea">

	<div class="divPanel">

		<div class="row-fluid">
			<div class="span3" id="footerArea1">

				<h3>O kompaniji</h3>

				<p>
					Apple Inc. ili Apple Computer, Inc. je američka računarska kompanija sa sjedištem u Silicijskoj dolini u gradu Cupertino, 
					savezna država Kalifornija. Apple je jedna od kompanija koja je pomogla pokretanju revolucije u osobnim računalima (PC) u kasnim 1970-im.
				    Smatra se kako je njezin Apple II praktički pokrenuo industriju poslovnih kompjutera nakon čega je proizvela Macintosh, 
				    prvi uspješni kompjuter s grafičkim operativnim sistemom čiji će dijelovi potom biti kopirani u nastanku Windowsa. 
				    Krajem 1990-ih je Apple promijenio svoj fokus s kompjutera na druge proizvode od kojih su najpoznatiji iPod, iTunes Music Store i Iphone. 
				    Zbog svega toga je Apple stekao reputaciju najveće svjetske tehnološke korporacije 2011. u doba smrti njenog osnivača i dugogodišnjeg generalnog direktora 
				    Stevea Jobsa.
				</p>

				<p>
					<a href="#" title="Terms of Use">Uvjeti korištenja</a>
					<br />
					<a href="#" title="Privacy Policy">Privacy Policy</a>
					<br />
					<a href="#" title="FAQ">Česta pitanja</a>
					<br />
					<a href="#" title="Sitemap">Mapa</a>
				</p>

			</div>
			<div class="span3" id="footerArea2">

				<h3>Nedavni postovi</h3>
				<p>
					<a href="#" title="">Lorem Ipsum is simply dummy text</a>
					<br />
					<span style="text-transform:none;">2 hours ago</span>
				</p>
				<p>
					<a href="#" title="">Duis mollis, est non commodo luctus</a>
					<br />
					<span style="text-transform:none;">5 hours ago</span>
				</p>
				<p>
					<a href="#" title="">Maecenas sed diam eget risus varius</a>
					<br />
					<span style="text-transform:none;">19 hours ago</span>
				</p>
				<p>
					<a href="#" title="">VIDI SVE POSTOVE</a>
				</p>

			</div>
			<div class="span3" id="footerArea3">

				<h3>Sample Footer Content</h3>
				<p>
					Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
				</p>
				<p>
					Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
				</p>

			</div>
			<div class="span3" id="footerArea4">

				<h3>Get in Touch</h3>

				<ul id="contact-info">
					<li>
						<i class="general foundicon-phone icon"></i>
						<span class="field">Telefon:</span>
						<br />
						(123) 456 7890 / 456 7891
					</li>
					<li>
						<i class="general foundicon-mail icon"></i>
						<span class="field">Email:</span>
						<br />
						<a href="mailto:info@yourdomain.com" title="Email">info@yourdomain.com</a>
					</li>
					<li>
						<i class="general foundicon-home icon" style="margin-bottom:50px"></i>
						<span class="field">Adresa:</span>
						<br />
						123 Street
						<br />
						12345 City, State
						<br />
						Country
					</li>
				</ul>

			</div>
		</div>

		<br />
		<br />
		<div class="row-fluid">
			<div class="span12">
				<p class="copyright">
					Copyright © 2013 Your Company. All Rights Reserved. Thanks to <a href="http://www.oswt.co.uk/">oswt</a>
				</p>

				<p class="social_bookmarks">
					<a href="#"><i class="social foundicon-facebook"></i> Facebook</a>
					<a href="https://twitter.com/oswt"><i class="social foundicon-twitter"></i> Twitter</a>
					<a href="#"><i class="social foundicon-pinterest"></i> Pinterest</a>
					<a href="#"><i class="social foundicon-rss"></i> Rss</a>
				</p>
			</div>
		</div>

	</div>
</div>
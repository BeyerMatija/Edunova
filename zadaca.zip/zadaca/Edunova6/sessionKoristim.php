<?php

session_start();

echo $_SESSION["pohranio"];

?>

<a href="sessionUnisti.php">Uništi</a>

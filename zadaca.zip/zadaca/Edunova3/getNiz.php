<?php  // početak
//ulaz
$p1= $_GET["p1"];
$p2 = $_GET["p2"];

//obrada
$rez = $p1 + $p2;

//izlaz
echo $rez;


//skraćeno
echo $_GET["p1"] + $_GET["p2"];


//Kraj
?>
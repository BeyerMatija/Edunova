<?php include_once 'konfiguracija.php'; ?>
<!doctype html>
<html class="no-js" lang="en" dir="ltr">
	<head>
		<?php include_once 'head.php'; ?>
	</head>
	<body>
		<header>
			<?php include_once 'izbornik.php'; ?>
			<?php include_once 'zaglavlje.php'; ?>
		</header>

		<div class="row">
			<div class="large-4 large-centered columns">
				
				
				Zadatak 5.1.
				<form method="post">
					<label for="broj">Unesite broj</label>
					<input type="text" name="broj" id="broj" 
					value="<?php echo isset($_POST["broj"]) ? $_POST["broj"] : 10 ?>" />
					<input type="submit" value="Zbroji" class="expanded button" />
				</form>
				
				<?php 
				if(isset($_POST["broj"])){
					$ukupno=0;
					for($i=0;$i<$_POST["broj"];$i++){
						$ukupno+=$i;
					}
					echo $ukupno;
				}
				
				?>
				
			</div>
		</div>

		

		<footer>
			<?php include_once 'podnozje.php'; ?>
		</footer>

		<?php include_once 'skripte.php'; ?>
	</body>
</html>

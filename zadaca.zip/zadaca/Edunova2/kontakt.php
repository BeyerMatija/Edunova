<?php include_once 'konfiguracija.php'; ?>
<!doctype html>
<html class="no-js" lang="en" dir="ltr">
	<head>
		<?php include_once 'head.php'; ?>
	</head>
	<body>
		<header>
			<?php include_once 'izbornik.php'; ?>
			<?php include_once 'zaglavlje.php'; ?>
		</header>

		<div class="row">
			<div class="columns">
				Kontakt
			</div>
		</div>

		

		<footer>
			<?php include_once 'podnozje.php'; ?>
		</footer>

		<?php include_once 'skripte.php'; ?>
	</body>
</html>

<?php

//Program ispisuje umnožak svih primljenih brojeva putem GET metode

print_r($_GET);
echo "<br />";
$zbroj=1;
foreach($_GET as $b){
	$zbroj*=$b;
}
echo $zbroj;
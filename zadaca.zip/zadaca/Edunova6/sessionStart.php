<?php

session_start();

$_SESSION["pohranio"]=78;

?>
<a href="sessionKoristim.php">Koristi</a>


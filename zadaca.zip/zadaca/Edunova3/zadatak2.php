<?php

//stranica prima ime te ga ispisuje u h1 oznaci

?>

<h1><?php echo $_GET['ime'] ?></h1>
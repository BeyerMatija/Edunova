<?php
//ZNAKOVNE FUNCKIJE
$grad="Osijek";

//echo str_replace("O", "najbolji grad O", $grad);
//echo substr($grad, 2,2);

$grad="Ja živim u Osijeku";
//echo strpos($grad, "Osijek");
//echo substr($grad, strpos($grad, "Osijek"));
$grad = " Osijek          ";
//echo "<pre>&gt;";
//echo trim($grad);
//echo "&lt;</pre>";

$grad="osIjek";

//echo  strtoupper($grad);


//JSON FUNKCIJE
$jsonString='{"error":{"message":"(#803) Cannot query users by their username (tjakopec)","type":"OAuthException","code":803,"fbtrace_id":"BSDctuJdMwJ"}}';

$objekt = json_decode($jsonString);

//print_r($objekt);


$niz=array("A"=>1,"B"=>2,"C" => 3);

//echo json_encode($niz);


//DATUMSKE FUNKCIJE
//http://php.net/manual/en/function.date.php


//echo date("d. m. Y.");

//echo date("d. m. Y. H:i:s",strtotime("2014-01-25 18:30:20"));
//trenutno vrijeme i sekunde
//echo date("d. m. Y. H:i:s",getdate()[0]);

//MATEMATIČE FUNKCIJE
//echo sqrt(9);
//echo pow(2,3);
//echo abs(-6);
//echo pi();

$niz=array();

for($i=0;$i<1000;$i++){
	$niz[]=rand(-200, 200);
}

//echo json_encode($niz);

$t=3.14;

//echo floor($t);
//echo ceil($t);


//NUMERIČKE FUNCKIJE
$broj =intval("23");
echo is_int($broj);








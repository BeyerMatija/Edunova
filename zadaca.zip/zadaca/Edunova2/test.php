<?php

//ako PHP u sebi nema HTML-a nije potrebno zatvarati <?php oznaku

echo "Hello\n";
echo "<br />";
echo "Osijek";

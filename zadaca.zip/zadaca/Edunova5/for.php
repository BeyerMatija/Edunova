<?php

//ispisati osijek 10 puta jedno ispod drugog
//petlje - loops - iteracija - ponavljanje koda

$t=0;
$t=$t+1;
//1
$t+=1;
//2
$t++;
//3
$t--;
//2
//echo ++$t; //prvo zbroj pa ispiše 3
//echo $t++; //prvo ispiše pa zbroji 3
// 4
--$t;
// 3



for($i=0;$i<10;$i++){
	
	echo "Osijek<br />\n";
	
	
}

?>

<hr />


<?php 
for($i=0;$i<10;$i++):
	?>
	Osijek<br />
	<?php
endfor;
 ?>
 
 <hr />


<?php 
for($i=0;$i<10;$i+=2):
	?>
	Osijek<br />
	<?php
endfor;
 ?>
 
 
 
 <hr />

<ol>
<?php 
//unos od korisnika
$pocetak=23;
$kraj=100;

for($i=$pocetak;$i<$kraj;$i++):
	?>
	<li>Osijek</li>
	<?php
endfor;
 ?>
 </ol>
 
 
 
  
 <hr />

<ul>
<?php 
//unos od korisnika
$pocetak=23;
$kraj=100;
$preskoci = array(50,55,56,60);
for($i=$pocetak;$i<$kraj;$i++):
	if(in_array($i, $preskoci)){
		continue;
	}
	?>
	<li><?php echo $i; ?>. Osijek</li>
	<?php
endfor;
 ?>
 </ul>
 
 
  <hr />

<ul>
<?php 
//unos od korisnika
$pocetak=23;
$kraj=100;
$ukupno=0;
for($i=$pocetak;$i<$kraj;$i++):
	if(++$ukupno>50){
		break;
	}
	?>
	<li><?php echo $ukupno; ?>. Osijek</li>
	<?php
endfor;
 ?>
 </ul>
 
 
   <hr />

<ul>
<?php 
//bESKONAČNA PETLJA
$ukupno=0;
for(;;):
	if(++$ukupno>50){
		break;
	}
	?>
	<li><?php echo $ukupno; ?>. Osijek</li>
	<?php
endfor;
 ?>
 </ul>



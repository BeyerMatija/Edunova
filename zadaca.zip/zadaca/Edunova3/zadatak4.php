<?php

$rez = $_GET["p1"]+$_GET["p2"]+$_GET["p3"]+$_GET["p4"]+$_GET["p5"];

//Program prima 5 brojeva. Ispisuje sve primljene brojeve i njihov zbroj

//primjer
// 4 + 3 + 7 + 5 + 2 = 21
//echo $rez;
?>
<?php echo $_GET["p1"]; ?> + 
<?php echo $_GET["p2"]; ?> +
<?php echo $_GET["p3"]; ?> +
<?php echo $_GET["p4"]; ?> +
<?php echo $_GET["p5"]; ?> = <?php echo $rez; ?> 
<hr />
<?php 
	echo $_GET["p1"] . " + " . $_GET["p2"]
	 . " + " . $_GET["p3"] . " + " . $_GET["p4"] . " + " . $_GET["p5"]
	  . " = " . $rez; 
 ?>
 <hr />
 <?php 
 //prvo uzeti sve u varijable pa ih onda ispisivati
	echo "$rez + $rez  =  $rez"; 
 ?>

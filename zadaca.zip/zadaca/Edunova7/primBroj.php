<?php

include_once 'funkcije.php';

echo "Broj 255" . (primBroj(255) ? " je " : " nije ") . "prim"; 


echo "<hr />";
//lošije rješenje
for($v=70;$v<299;$v++){
	$prim=true;
	for($i=2;$i<$v;$i++){
		if($v%$i==0){
			$prim=false;
			break;
		}
	}
	echo "Broj " . $v . " " . ($prim ? " je " : " nije ") . "prim<br />"; 
}


echo "<hr />";
//bolje rješenje
for($v=70;$v<299;$v++){
	//echo "Broj " . $v . " " . (primBroj($v) ? " je " : " nije ") . "prim<br />";
	//ovo ne raditi
	//$rez = primBroj($v);
	//if($rez==true){
	//ovako pitati na boolean
	if(primBroj($v)){
		echo $v . "<br />";
	} 
}

echo count($_SERVER);
echo "<hr />";
echo zbroj(1,2);
echo "<hr />";
echo zbroj(3);
echo "<hr />";

_log($_SERVER);

//phpInformacije();

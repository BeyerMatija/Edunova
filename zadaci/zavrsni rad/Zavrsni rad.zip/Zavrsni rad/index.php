
<!doctype html>
<html class="no-js" lang="en" dir="ltr">
  <head>
    <?php include_once 'predlosci/head.php'; ?>
  </head>
  <body>
  	<?php include_once 'predlosci/menu.php'; ?>
  	
    <div class="grid-container">
    	
      <div class="row">
      	
        <div class="large-8 cell">
        	 <br><br>
        	
    	
        	
        	
 
 
        </div>
    </div>
 </div>
	<?php	include_once 'predlosci/podnozje.php'; ?>
   <?php	include_once 'predlosci/skripte.php'; ?>
  </body>
</html>

<?php

//stranica prima dva paramtera. Ispisuje ih kao stavke numerirane liste

?>
<ol>
	<li><?php echo $_GET["p1"] ?></li>
	<li><?php echo $_GET["p2"] ?></li>
</ol>
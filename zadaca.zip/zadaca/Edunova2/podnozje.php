<div class="row expanded callout secondary">

	<div class="large-4 columns">
		<h5>Najzanimljivije slike</h5>
		<div class="row small-up-4">
			<?php
			
			//$brojSlika = isset($_GET["brojSlika"]) ? $_GET["brojSlika"] : 8;
			$brojSlika = !isset($_GET["brojSlika"]) ? 8 : $_GET["brojSlika"] ;
			for($i=0;$i<$brojSlika;$i++):
			 ?>
			<div class="column"><img class="thumbnail" src="http://placehold.it/75" alt="image of space dog">
			</div>
			<?php endfor; ?>
			
		</div>

	</div>

	<div class="large-4 columns">
		<h5>FLICKR IMAGES</h5>
		<?php
			
			//$brojSlika = isset($_GET["brojSlika"]) ? $_GET["brojSlika"] : 8;
			$brojOznaka = !isset($_GET["brojOznaka"]) ? 8 : $_GET["brojOznaka"] ;
			for($i=0;$i<$brojOznaka;$i++):
			 ?>
			<span class="secondary label">Oznaka <?php echo $i+1; ?></span>
			<?php endfor; ?>
		
		
	</div>

	<div class="large-4 columns">
		<h5>RANDOM MAG</h5>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti quam voluptatum vel repellat ab similique molestias molestiae ea omnis eos, id asperiores est praesentium, voluptate officia nulla aspernatur sequi aliquam.
		</p>
	</div>

</div>
<div class="row expanded">

	<div class="medium-6 columns">
		<ul class="menu">
			<li>
				<a href="#">Legal</a>
			</li>
			<li>
				<a href="#">Partner</a>
			</li>
			<li>
				<a href="#">Explore</a>
			</li>
		</ul>
	</div>

	<div class="medium-6 columns">
		<ul class="menu align-right">
			<li class="menu-text" style="font-size: 0.5em; font-weight: normal">
				Koristite: <?php echo $_SERVER["HTTP_USER_AGENT"] ?>
			</li>
		</ul>
	</div>
</div>
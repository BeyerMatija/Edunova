<?php include_once 'konfiguracija.php'; ?>
<!doctype html>
<html class="no-js" lang="en" dir="ltr">
	<head>
		<?php include_once 'head.php'; ?>
	</head>
	<body>
		<header>
			<?php include_once 'izbornik.php'; ?>
			<?php include_once 'zaglavlje.php'; ?>
		</header>

		<div class="row">
			<div class="large-4 columns large-centered">
				
				<?php 
				if(isset($_GET["neuspio"])){
					echo "Ne ispravna kombinacija korisnika i lozinke!";
				}
				
				if(isset($_GET["nemateOvlasti"])){
					echo "Morate se prvo logirati!";
				}
				 ?>
				
				<form method="post" action="autoriziraj.php">
					<label for="korisnik">Korisnik</label>
					<input type="text" name="korisnik" id="korisnik" 
					value="<?php echo isset($_GET["korisnik"]) ? $_GET["korisnik"] : ""; ?>"/>
					<label for="lozinka">Lozinka</label>
					<input type="password" name="lozinka" id="lozinka" />
					<input type="submit" class="button expanded" value="Autoriziraj" />
				</form>
			</div>
		</div>

		

		<footer>
			<?php include_once 'podnozje.php'; ?>
		</footer>

		<?php include_once 'skripte.php'; ?>
	</body>
</html>

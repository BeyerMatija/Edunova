<ul class="dropdown-menu">
	<li class="dropdown">
		<a href="#" class="dropdown-toggle">Padajući izbornik &nbsp;&raquo;</a>
		<ul class="dropdown-menu sub-menu">
			<li>
				<a href="#">Proizvod 1</a>
			</li>
			<li>
				<a href="#">Proizvod 2</a>
			</li>
			<li>
				<a href="#">Proizvod 3</a>
			</li>
		</ul>
	</li>
	<li>
		<a href="#">Proizvod 4</a>
	</li>
	<li>
		<a href="#">Proizvod 5</a>
	</li>
	<li>
		<a href="#">Proizvod 6</a>
	</li>
</ul>
<?php

//program prima 3 broja i ispisuje najveći

$b1=isset($_GET["b1"]) ? $_GET["b1"] : 3;
$b2=isset($_GET["b2"]) ? $_GET["b2"] : 3;
$b3=isset($_GET["b3"]) ? $_GET["b3"] : 3;


if($b1>$b2 && $b1>$b3){
	echo $b1;
}

if($b2>$b1 && $b2>$b3){
	echo $b2;
}

if($b3>$b1 && $b3>$b2){
	echo $b3;
}

?>
<hr />
<?php

//za n broj parametara putem GET metode 
//program ispisuje najveći broj


print_r($_GET);
echo "<br />";

foreach ($_GET as $kljuc => $vrijednost) {
	echo $kljuc . "<br />";
}

echo "<br />";
$najveci=-1000000;
foreach ($_GET as  $vrijednost) {
	if($vrijednost>$najveci){
		$najveci=$vrijednost;
	}
}

echo $najveci;
















<?php

//program ispisuje zbroj svih primljenih brojeva putem GET metode

print_r($_GET);
echo "<br />";
$zbroj=0;
foreach($_GET as $b){
	$zbroj+=$b;
}
echo $zbroj;

<script src="<?php echo $putanjaAPP;  ?>js/vendor/jquery.js"></script>
<script src="<?php echo $putanjaAPP;  ?>js/vendor/what-input.js"></script>
<script src="<?php echo $putanjaAPP;  ?>js/vendor/foundation.js"></script>
<script src="<?php echo $putanjaAPP;  ?>js/app.js"></script>
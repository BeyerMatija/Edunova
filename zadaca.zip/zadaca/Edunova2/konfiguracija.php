<?php

$naslovAplikacije="Znanje";

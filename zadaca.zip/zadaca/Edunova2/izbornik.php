<!-- Sub Navigation -->
<div class="top-bar" style="<?php 

if($_SERVER["HTTP_HOST"]==="localhost"){
	echo "background-color: red;";
}

?>">
	<div class="top-bar-left">
		<ul class="menu">
			<li>
				<a href="index.php"><?php echo $naslovAplikacije ?></a>
			</li>
			<li>
				<a href="onama.php">O nama</a>
			</li>
			<li>
				<a href="kontakt.php">Kontakt</a>
			</li>
			<li>
				<ul class="dropdown menu" data-dropdown-menu>
			        <li>
			          <a href="#">Zadaci</a>
			          <ul class="menu vertical">
			            <li><a href="zadatak51.php">Broj prvih n brojeva</a></li>
			            <li><a href="zadatak52.php">Prim broj</a></li>
			          </ul>
			        </li>
		        </ul>
			</li>
			
       
      </ul>
			</li>
		</ul>
	</div>
	<div class="top-bar-right">
		<ul class="menu">

			<li>
				<a href="login.php" class="button">Login</a>
			</li>
		</ul>
	</div>
</div>
<!-- /Sub Navigation -->

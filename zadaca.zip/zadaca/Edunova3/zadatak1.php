<?php

// stranica prima parametar boja i 
// bude te boje koju je vrijednost primila

//zadatak1.php?boja=red

?>
<html>
	<body style="background-color: #<?php echo $_GET["boja"] ?>"></body>
</html>
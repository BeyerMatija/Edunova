<?php
//funkcije koja prima jedan paramatar i vraća vrijednost
function primBroj($provjeri){
	$prim=true;
	for($i=2;$i<$provjeri;$i++){
		if($provjeri%$i==0){
			$prim=false;
			break;
		}
	}
	return $prim;
}

//prima jedan parametar i ne vraća vrijednost
function _log($poruka){
	echo "<hr />print_r";
	echo "<pre>";
	print_r($poruka);
	echo "</pre>";
	echo "<hr />var_dump";
	echo "<pre>";
	var_dump($poruka);
	echo "</pre>";
}
//ne prima parametre i ne vraća vrijednost
function phpInformacije(){
	phpinfo();
}
//funkcija prima dva parametra i vraća vrijednost
function zbroj($x,$y=0){
	return $x + $y;
}

<?php include_once 'konfiguracija.php'; ?>
<!doctype html>
<html class="no-js" lang="en" dir="ltr">
	<head>
		<?php include_once 'head.php'; ?>
	</head>
	<body>
		<header>
			<?php include_once 'izbornik.php'; ?>
			<?php include_once 'zaglavlje.php'; ?>
		</header>

		<div class="row">
			<div class="medium-8 columns">
				<div 
				<?php //PHP unutar definicije elementa  ?> 
				<?php 
				
				
				print 'class="callout"';
				
				echo " id=\"d1\" ";
				
				
				 ?> style="min-height: 400px;">
					<?php echo $naslovAplikacije ?>
					
					<!-- PHP unutar sadržaja elementa -->
					<?php
					
					/*
					 Komentar više linija
					  */
					//for($i=0;$i<10;$i++)
					echo "<h1>Hello world</h1>";
					
					
					
					?>
					
					<!-- PHP koji lomi html element NEĆEMO KORISTITI -->
				<?php //echo "</div>";  ?>
				</div>
			</div>
			<div class="medium-4 columns">
				<p><img src="http://placehold.it/400x200&text=Edunova" alt="article promo image" alt="advertisement for deep fried Twinkies">
				</p>
				<p><img src="http://placehold.it/400x200&text=Other cool article" alt="article promo image">
				</p>
			</div>
		</div>

		

		<footer>
			<?php include_once 'podnozje.php'; ?>
		</footer>

		<?php include_once 'skripte.php'; ?>
	</body>
</html>
